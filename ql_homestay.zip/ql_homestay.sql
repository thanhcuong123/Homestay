-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2025 at 01:03 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `homestay`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrative_units`
--

CREATE TABLE `administrative_units` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('Phường','Huyện') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `administrative_units`
--

INSERT INTO `administrative_units` (`id`, `name`, `type`, `created_at`, `updated_at`) VALUES
(1, 'Thành phố', 'Phường', NULL, NULL),
(2, 'Xã', 'Phường', NULL, NULL),
(3, 'Huyện', 'Huyện', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `room_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `check_in_date` date NOT NULL,
  `check_out_date` date NOT NULL,
  `status` enum('Confirmed','Pending','Cancelled') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `distances`
--

CREATE TABLE `distances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `homestay_id` bigint(20) UNSIGNED NOT NULL,
  `tourist_spot_id` bigint(20) UNSIGNED NOT NULL,
  `distance` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `homestay_id` bigint(20) UNSIGNED NOT NULL,
  `message` text NOT NULL,
  `status` enum('Processed','Pending') NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `homestays`
--

CREATE TABLE `homestays` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `owner_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `administrative_unit_id` bigint(20) UNSIGNED DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `homestays`
--

INSERT INTO `homestays` (`id`, `owner_id`, `name`, `address`, `latitude`, `longitude`, `administrative_unit_id`, `image`, `created_at`, `updated_at`) VALUES
(12, 10, 'La’ANh Boutique Stay', '156/43 Đoàn Thị Điểm, phường Cái Khế, quận Ninh Kiều, thành phố Cần Thơ.', 10.04520000, 105.74690000, 1, 'uploads/homestay/1742482754_Screenshot 2025-03-05 100902.png', '2025-03-03 23:49:05', '2025-03-20 07:59:14'),
(14, 14, 'Winter Spring Homestay', '76 Ung Văn Khiêm, P. Cái Khế, Q. Ninh Kiều, TP. Cần Thơ', 10.04520000, 105.74690000, 1, 'uploads/homestay/1742482817_Screenshot 2025-03-05 101412.png', '2025-03-03 23:50:05', '2025-03-20 08:00:17'),
(15, 12, 'Winter Spring Colors House', 'Hẻm 132 (120/15A) Trần Phú, P. Cái Khế, Q. Ninh Kiều, TP Cần Thơ', 10.04520000, 105.74690000, 1, 'uploads/homestay/1742482830_Screenshot 2025-03-05 101823.png', '2025-03-04 00:05:06', '2025-03-20 08:00:30'),
(16, 13, 'Green Garden Homestay', '97 Đ. Đồng Văn Cống, An Thới, Bình Thủy, Cần Thơ 92000, Việt Nam', 10.04520000, 105.74690000, 1, 'uploads/homestay/1742482861_Screenshot 2025-03-05 103252.png', '2025-03-04 00:05:58', '2025-03-20 08:01:01'),
(17, 13, '08 Homestay', '118 Đ. Bà Huyện Thanh Quan, Thới Bình, Ninh Kiều, Cần Thơ', 10.04558000, 105.77789900, 1, 'uploads/homestay/1742482871_Screenshot 2025-03-05 103003.png', '2025-03-04 00:06:42', '2025-03-21 05:23:10'),
(22, 11, 'AT Homestay Cần Thơ', '15 Đường Số 1, KDC Metro, Ninh Kiều, Cần Thơ 90000, Việt Nam', 10.04520000, 105.74690000, 1, 'uploads/homestay/1742817710_Screenshot 2025-03-05 103252.png', '2025-03-18 07:14:22', '2025-03-24 05:01:50'),
(23, 14, 'AT Homestay Cần Thơ 2', 'hồ chí minh', 10.77584400, 106.70175600, 1, 'uploads/homestay/1742483898_Screenshot 2025-03-05 103252.png', '2025-03-20 08:18:18', '2025-03-20 08:18:18');

-- --------------------------------------------------------

--
-- Table structure for table `homestay_images`
--

CREATE TABLE `homestay_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `homestay_id` bigint(20) UNSIGNED NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000001_create_cache_table', 1),
(2, '0001_01_01_000002_create_jobs_table', 1),
(3, '2025_02_21_104242_create_owners_table', 1),
(4, '2025_02_21_104758_create_administrative_units_table', 1),
(5, '2025_02_21_104944_create_homestays_table', 1),
(6, '2025_02_21_105421_create_room_types_table', 1),
(7, '2025_02_21_105615_create_rooms_table', 1),
(8, '2025_02_21_105722_create_services_table', 1),
(9, '2025_02_21_110006_create_tourist_spots_table', 1),
(10, '2025_02_21_110035_create_distances_table', 1),
(11, '2025_02_21_110111_create_users_table', 1),
(12, '2025_02_21_110211_create_bookings_table', 1),
(13, '2025_02_21_115109_create_reviews_table', 1),
(14, '2025_02_21_115205_create_feedbacks_table', 1),
(15, '2025_02_21_120420_create_sessions_table', 1),
(16, '2025_02_25_153526_create_homestay_images_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `owners`
--

CREATE TABLE `owners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` enum('Nam','Nữ') NOT NULL,
  `phone` varchar(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `owners`
--

INSERT INTO `owners` (`id`, `name`, `gender`, `phone`, `created_at`, `updated_at`) VALUES
(10, 'Như', 'Nữ', '0898490715', '2025-03-03 23:45:36', '2025-03-03 23:45:36'),
(11, 'danh thanh cường', 'Nam', '0702892014', '2025-03-03 23:46:08', '2025-03-03 23:46:08'),
(12, 'Vũ Lang', 'Nam', '0981650033', '2025-03-03 23:46:38', '2025-03-03 23:46:38'),
(13, 'Bang', 'Nam', '0916757510', '2025-03-03 23:47:05', '2025-03-03 23:47:05'),
(14, 'Trúc Quỳnh', 'Nữ', '0916757510', '2025-03-03 23:47:35', '2025-03-03 23:47:35');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `homestay_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `room_type_id` bigint(20) UNSIGNED NOT NULL,
  `room_number` varchar(50) NOT NULL,
  `status` enum('đã có người ở','đã đặt','còn trống') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `image` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `room_type_id`, `room_number`, `status`, `created_at`, `updated_at`, `image`) VALUES
(6, 5, '7', 'đã đặt', '2025-03-04 00:11:07', '2025-03-04 00:11:07', 'uploads/room/1741072267_Screenshot 2024-08-27 232145.png');

-- --------------------------------------------------------

--
-- Table structure for table `room_types`
--

CREATE TABLE `room_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `homestay_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `max_guests` int(11) NOT NULL,
  `area` decimal(10,2) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `amenities` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `room_types`
--

INSERT INTO `room_types` (`id`, `homestay_id`, `name`, `max_guests`, `area`, `price`, `created_at`, `updated_at`, `amenities`) VALUES
(5, 12, 'Phòng doule', 2, 20.00, 650000.00, '2025-03-04 00:09:05', '2025-03-04 00:09:05', 'Dịch vụ La’ANh còn có hỗ trợ thuê xe máy cho những ai có nhu cầu di chuyển tự túc - Nội thất full tiện ích như: \r\n* Bếp ăn\r\n* Máy giặt\r\n* Tủ lạnh…'),
(6, 14, 'Homestay', 22, 20.00, 400.00, '2025-03-24 04:47:37', '2025-03-24 04:47:37', 'Số lượng phòng: 2 phòng gia đình 2 giường, 1 phòng 3 giường, 4 phòng 1 giường\r\n• Sức chứa từ 22-30 khách\r\n• 2 Bếp đủ tiện nghi như ở nhà.\r\n• Máy lạnh, TV, tủ lạnh, quạt, võng thư giãn'),
(7, 15, 'Homestay', 22, 250.00, 400.00, '2025-03-24 04:48:20', '2025-03-24 04:48:20', 'Thoải mái cho nhóm từ 22 – 30 khách, 7 phòng ngủ, 7 toilets, 11 giường, nhiều nệm xếp, bếp đủ tiện nghi.'),
(8, 16, 'Homestay', 22, 250.00, 400.00, '2025-03-24 04:48:46', '2025-03-24 04:48:46', 'Thoải mái cho nhóm từ 22 – 30 khách, 7 phòng ngủ, 7 toilets, 11 giường, nhiều nệm xếp, bếp đủ tiện nghi.');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `homestay_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('Y1qGcHrMTSTV4y9mG2vwnXmCm59JnfGKPhwjax9b', 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiQ1Q4em00VFFnZUJQeEdnemNqMGdJNTdWbDlSdU1kdUhhWDhLM2VuZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9ob21lc3RheS8yMiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7fQ==', 1742817744);

-- --------------------------------------------------------

--
-- Table structure for table `tourist_spots`
--

CREATE TABLE `tourist_spots` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tourist_spots`
--

INSERT INTO `tourist_spots` (`id`, `name`, `address`, `latitude`, `longitude`, `icon`, `created_at`, `updated_at`) VALUES
(8, 'Công viên Văn hóa Miền Tây', 'Đ. Cách Mạng Tháng 8, An Hoà, Bình Thủy, Cần Thơ, Việt Nam', 10.05829700, 105.76721700, 'uploads/tourist/1742816496_Công viên văn hóa miền tây.webp', '2025-03-24 04:41:36', '2025-03-24 04:41:36'),
(9, 'Công viên sông Hậu', '2QXR+Q95, Cái Khế, Ninh Kiều, Cần Thơ, Việt Nam', 10.04911586, 105.79063580, 'uploads/tourist/1742816567_Công viên sông hậu.jpg', '2025-03-24 04:42:47', '2025-03-24 04:42:47'),
(10, 'Nhà Trực Thăng Cần Thơ', '179 Đường số 6, Kdc Thới Nhựt 2, Ninh Kiều, Cần Thơ, Việt Nam', 10.04420100, 105.75650000, 'uploads/tourist/1742816615_Nhà trực thăng cần thơ.jpg', '2025-03-24 04:43:35', '2025-03-24 04:43:35'),
(11, 'Chùa Thới Long Cổ Tự', '120 Hùng Vương, An Cư, Ninh Kiều, Cần Thơ, Việt Nam', 10.04347000, 105.77852400, 'uploads/tourist/1742816654_Chùa thới long cổ tự.jpg', '2025-03-24 04:44:14', '2025-03-24 04:44:14'),
(12, 'Thanh Trúc\'s Purple Haven of Healing', 'XRF5+J7R, Tân Phú, Cái Răng, Cần Thơ, Việt Nam', 9.97971200, 105.82197000, 'uploads/tourist/1742816684_Thanh Trúc\'s Purple Haven of Healing.jpg', '2025-03-24 04:44:44', '2025-03-24 04:44:44'),
(13, 'Du Lịch Sinh Thái Chính Vườn', 'KV Thạnh Thắng,Q, Cái Răng, Cần Thơ, Việt Nam', 10.00046600, 105.80253600, 'uploads/tourist/1742816709_Du Lịch Sinh Thái Chính Vườn.jpg', '2025-03-24 04:45:09', '2025-03-24 04:45:09');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `gender` enum('Nam','Nữ') DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone`, `address`, `gender`, `date_of_birth`, `avatar`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'cường', 'cuong@gmail.com', '123456', '0964094049', 'cần thơ', 'Nam', '2025-02-25', NULL, 'admin', NULL, '2025-02-25 15:40:44', NULL),
(2, 'Danh Thanh Cường', 'cuong123456@gmail.com', '$2y$12$4nVLdwZrI20I05J1edPZ3eJmWnzZ4HFB.cl.NSyc04PVGfNeh/3IC', '0964094074', 'Hà Nội', 'Nam', NULL, NULL, 'admin', NULL, '2025-02-25 08:42:46', '2025-02-25 08:42:46'),
(3, 'Danh Thanh Cường', 'cuong555@gmail.com', '$2y$12$TA3ruxJ42G1aRK62hS/7FuvylA1EC9Er.kGm/VX3hHpzW2RBXvPTC', '0964094024', 'Hà Nội', 'Nam', NULL, NULL, 'user', NULL, '2025-02-25 08:42:46', '2025-02-25 08:42:46'),
(4, 'Quynh', 'quynh@gmail.com', '$2y$12$EGsZbufl7vUqzOw1IM0Ice17ktYaY8HC4Ujc2ktyMCXEWA376eXaG', NULL, NULL, 'Nữ', NULL, NULL, 'admin', NULL, NULL, '2025-02-25 09:52:37'),
(5, 'Admin', 'Admin@gmail.com', '$2y$12$EGjDbn5ENT7geRn2VjYlaO.3hd6E3V7n7.GwRMmDFE6hjZwojIMRa', '0964094074', 'cần thơ', 'Nam', '2025-03-11', NULL, 'admin', NULL, NULL, '2025-03-05 07:41:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrative_units`
--
ALTER TABLE `administrative_units`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bookings_room_id_foreign` (`room_id`),
  ADD KEY `bookings_user_id_foreign` (`user_id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `distances`
--
ALTER TABLE `distances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `distances_homestay_id_foreign` (`homestay_id`),
  ADD KEY `distances_tourist_spot_id_foreign` (`tourist_spot_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `feedbacks_user_id_foreign` (`user_id`),
  ADD KEY `feedbacks_homestay_id_foreign` (`homestay_id`);

--
-- Indexes for table `homestays`
--
ALTER TABLE `homestays`
  ADD PRIMARY KEY (`id`),
  ADD KEY `homestays_owner_id_foreign` (`owner_id`),
  ADD KEY `homestays_administrative_unit_id_foreign` (`administrative_unit_id`);

--
-- Indexes for table `homestay_images`
--
ALTER TABLE `homestay_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `homestay_images_homestay_id_foreign` (`homestay_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `owners`
--
ALTER TABLE `owners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reviews_homestay_id_foreign` (`homestay_id`),
  ADD KEY `reviews_user_id_foreign` (`user_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rooms_room_type_id_foreign` (`room_type_id`);

--
-- Indexes for table `room_types`
--
ALTER TABLE `room_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_types_homestay_id_foreign` (`homestay_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `services_homestay_id_foreign` (`homestay_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `tourist_spots`
--
ALTER TABLE `tourist_spots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrative_units`
--
ALTER TABLE `administrative_units`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `distances`
--
ALTER TABLE `distances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `homestays`
--
ALTER TABLE `homestays`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `homestay_images`
--
ALTER TABLE `homestay_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `owners`
--
ALTER TABLE `owners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `room_types`
--
ALTER TABLE `room_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tourist_spots`
--
ALTER TABLE `tourist_spots`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `distances`
--
ALTER TABLE `distances`
  ADD CONSTRAINT `distances_homestay_id_foreign` FOREIGN KEY (`homestay_id`) REFERENCES `homestays` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `distances_tourist_spot_id_foreign` FOREIGN KEY (`tourist_spot_id`) REFERENCES `tourist_spots` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD CONSTRAINT `feedbacks_homestay_id_foreign` FOREIGN KEY (`homestay_id`) REFERENCES `homestays` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `feedbacks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `homestays`
--
ALTER TABLE `homestays`
  ADD CONSTRAINT `homestays_administrative_unit_id_foreign` FOREIGN KEY (`administrative_unit_id`) REFERENCES `administrative_units` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `homestays_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `owners` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `homestay_images`
--
ALTER TABLE `homestay_images`
  ADD CONSTRAINT `homestay_images_homestay_id_foreign` FOREIGN KEY (`homestay_id`) REFERENCES `homestays` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_homestay_id_foreign` FOREIGN KEY (`homestay_id`) REFERENCES `homestays` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `rooms`
--
ALTER TABLE `rooms`
  ADD CONSTRAINT `rooms_room_type_id_foreign` FOREIGN KEY (`room_type_id`) REFERENCES `room_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `room_types`
--
ALTER TABLE `room_types`
  ADD CONSTRAINT `room_types_homestay_id_foreign` FOREIGN KEY (`homestay_id`) REFERENCES `homestays` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `services_homestay_id_foreign` FOREIGN KEY (`homestay_id`) REFERENCES `homestays` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
